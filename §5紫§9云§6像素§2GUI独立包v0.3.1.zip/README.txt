
紫云像素实时更新群:831376294
======================================================================
可点击下方链接查看更新详情与下载！也可在群文件下载！《紫云像素·材质包》
https://www.yuque.com/books/share/13af52b2-71e2-41b0-84e4-cc87ae09027e?
======================================================================
curseforge下载：
https://www.curseforge.com/minecraft/texture-packs/purple-cloud-pixel-original-enhancement
======================================================================
如果你有什么好的建议或反馈，可点击下方链接！
https://shimo.im/forms/J89jjjWWVJtvdKg9/fill
======================================================================
作者：紫云official
转载务必附上作者及原贴，禁止商业用途的转载和发布
遵循以下协议：
您可以自由地：
共享 - 在任何媒介以任何形式复制、发行本作品
演绎 - 修改、转换或以本作品为基础进行创作
只要你遵守许可协议条款，许可人就无法收回你的这些权利。

惟须遵守下列条件：
署名 - 您必须给出适当的署名，提供指向本许可协议的链接，同时标明是否（对原始作品）作了修改。
您可以用任何合理的方式来署名，但是不得以任何方式暗示许可人为您或您的使用背书。

非商业性使用 - 您不得将本作品用于商业目的。
相同方式共享 - 如果您再混合、转换或者基于本作品进行创作，您必须基于与原先许可协议相同的许可协议 分发您贡献的作品。
没有附加限制 - 您不得适用法律术语或者 技术措施 从而限制其他人做许可协议允许的事情。

English Version：
ZiYun pixel real-time update group: 831376294
======================================================================
You can click on the link below to view the update details and download it! You can also download from the group file! 
https://www.yuque.com/books/share/13af52b2-71e2-41b0-84e4-cc87ae09027e?
======================================================================
curseforge download.?
https://www.curseforge.com/minecraft/texture-packs/purple-cloud-pixel-original-enhancement
======================================================================
If you have any good suggestions or feedback, please click on the link below!
https://shimo.im/forms/J89jjjWWVJtvdKg9/fill
======================================================================
Author. ZiYun
Reproduction must indicate the author and original post, reproduction and publication for commercial use is prohibited
Follow the following protocol.
You are free to
Share - reproduce, distribute this work in any form in any medium
Perform - modify, transform or create based on this work
The licensor cannot withdraw these rights from you as long as you comply with the terms of the license agreement.

Subject to the following conditions.
Attribution - You must give proper attribution, provide a link to this License Agreement, and also indicate whether you have made any modifications (to the original work).
You may give attribution in any reasonable manner, but you may not in any way imply that the licensor approves of you or your use.

Non-Commercial Use - You may not use this work for commercial purposes.
Sharing in the same manner - If you remix, adapt, or create based on the Work, you must distribute your contribution under the same license agreement as the original license agreement.
No Additional Restrictions - You may not apply legal terms or technical measures that restrict others from doing what is permitted under the License Agreement.

Translated with www.DeepL.com/Translator (free version)